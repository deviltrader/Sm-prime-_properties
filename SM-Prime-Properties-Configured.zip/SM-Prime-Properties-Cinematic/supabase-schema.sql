-- SM Prime Properties / Supabase schema
-- Run all statements in Supabase SQL Editor as project owner.
-- Public users may read published listings and submit enquiries.
-- Only users allowlisted in property_admins may manage listings/read leads.

create extension if not exists pgcrypto;

create table if not exists public.property_admins (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);
alter table public.property_admins enable row level security;

create or replace function public.is_sm_prime_admin()
returns boolean language sql stable security definer set search_path = public
as $$
  select exists (select 1 from public.property_admins where user_id = (select auth.uid()));
$$;
revoke all on function public.is_sm_prime_admin() from public;
grant execute on function public.is_sm_prime_admin() to anon, authenticated;

drop policy if exists "Admins can read own allowlist entry" on public.property_admins;
create policy "Admins can read own allowlist entry" on public.property_admins
for select to authenticated using (user_id = (select auth.uid()));

create table if not exists public.properties (
  id uuid primary key default gen_random_uuid(),
  title text not null check (char_length(title) between 3 and 160),
  property_type text not null check (property_type in ('Layout Site','Residential Plot','House','Rental Home','Commercial','Apartment')),
  purpose text not null check (purpose in ('Sale','Rent')),
  location text not null check (char_length(location) between 2 and 160),
  price_inr numeric(14,2) not null check (price_inr > 0),
  area_sqft numeric(12,2) not null default 0 check (area_sqft >= 0),
  bedrooms integer not null default 0 check (bedrooms between 0 and 50),
  bathrooms integer not null default 0 check (bathrooms between 0 and 50),
  status text not null default 'Available' check (status in ('Available','Under Offer','Sold','Rented')),
  image_url text,
  description text not null default '',
  is_published boolean not null default false,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.properties enable row level security;
drop policy if exists "Public reads published listings" on public.properties;
create policy "Public reads published listings" on public.properties
for select to anon, authenticated using (is_published = true or public.is_sm_prime_admin());
drop policy if exists "Admins insert listings" on public.properties;
create policy "Admins insert listings" on public.properties
for insert to authenticated with check (public.is_sm_prime_admin());
drop policy if exists "Admins update listings" on public.properties;
create policy "Admins update listings" on public.properties
for update to authenticated using (public.is_sm_prime_admin()) with check (public.is_sm_prime_admin());
drop policy if exists "Admins delete listings" on public.properties;
create policy "Admins delete listings" on public.properties
for delete to authenticated using (public.is_sm_prime_admin());

create table if not exists public.leads (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 2 and 120),
  phone text not null check (char_length(phone) between 7 and 30),
  interest text not null check (interest in ('Buying a property','Renting a property','Selling my property','Leasing my property')),
  area text,
  message text,
  created_at timestamptz not null default now()
);
alter table public.leads enable row level security;
drop policy if exists "Visitors submit enquiries" on public.leads;
create policy "Visitors submit enquiries" on public.leads
for insert to anon, authenticated with check (char_length(name) between 2 and 120 and char_length(phone) between 7 and 30);
drop policy if exists "Admins read enquiries" on public.leads;
create policy "Admins read enquiries" on public.leads
for select to authenticated using (public.is_sm_prime_admin());
drop policy if exists "Admins delete enquiries" on public.leads;
create policy "Admins delete enquiries" on public.leads
for delete to authenticated using (public.is_sm_prime_admin());

insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types)
values ('property-images','property-images',true,8388608,array['image/jpeg','image/png','image/webp','image/avif'])
on conflict (id) do update set public=true,file_size_limit=8388608,allowed_mime_types=array['image/jpeg','image/png','image/webp','image/avif'];

drop policy if exists "Public view property images" on storage.objects;
create policy "Public view property images" on storage.objects
for select to anon, authenticated using (bucket_id='property-images');
drop policy if exists "Admins upload property images" on storage.objects;
create policy "Admins upload property images" on storage.objects
for insert to authenticated with check (bucket_id='property-images' and public.is_sm_prime_admin());
drop policy if exists "Admins update property images" on storage.objects;
create policy "Admins update property images" on storage.objects
for update to authenticated using (bucket_id='property-images' and public.is_sm_prime_admin())
with check (bucket_id='property-images' and public.is_sm_prime_admin());
drop policy if exists "Admins delete property images" on storage.objects;
create policy "Admins delete property images" on storage.objects
for delete to authenticated using (bucket_id='property-images' and public.is_sm_prime_admin());


-- Explicit grants for the browser roles used by the frontend.
grant usage on schema public to anon, authenticated;
grant select on public.properties to anon, authenticated;
grant insert, update, delete on public.properties to authenticated;
grant insert on public.leads to anon, authenticated;
grant select, delete on public.leads to authenticated;
grant select on public.property_admins to authenticated;
grant select on storage.objects to anon, authenticated;
grant insert, update, delete on storage.objects to authenticated;

-- Setup admin:
-- 1) Create your own user in Supabase Authentication > Users.
-- 2) Copy the user's UUID.
-- 3) Run: insert into public.property_admins(user_id) values ('YOUR-USER-UUID');
