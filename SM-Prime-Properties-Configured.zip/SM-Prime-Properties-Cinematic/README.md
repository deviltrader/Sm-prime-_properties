# SM Prime Properties — Cinematic Real Estate Website

Premium black-and-gold real estate website for Chitradurga, Karnataka. It is an original visual direction using immersive architectural photography, editorial typography, scroll reveals and cinematic sections.

## Features

- Responsive, animated landing page
- Search and filters for purpose, property category, locality and maximum budget
- Categories: layout sites, residential plots, houses, rental homes, commercial spaces and apartments
- Property details modal with price, area, status, map search and WhatsApp enquiry
- Owner login using Supabase Auth
- Admin listing management: create, edit, publish/unpublish and delete
- Photo uploads to Supabase Storage
- Enquiry submission and private admin inbox
- Row Level Security policies in `supabase-schema.sql`
- Netlify static deployment config

## No fabricated property inventory

The website starts with **zero published listings**. Add real, authorised listings through the owner dashboard after connecting Supabase. Hero and section imagery is illustrative architecture photography; it is not represented as a listing in Chitradurga.

## Start locally

The website is static. For a quick preview, open `index.html`. For a more realistic local server, run `python3 -m http.server 8080` inside this folder, then open `http://localhost:8080`. Admin and lead storage require Supabase configuration.

## Required setup

Read `DEPLOYMENT.md` and `LAUNCH-CHECKLIST.md`. You must create your own Supabase project, run the SQL, create and allowlist an owner user, and add the public Supabase URL/key to `config.js`. Optionally set a WhatsApp number. Do not expose a Supabase service-role key or database password in browser files.

## Current limitations

- Map links open a Google Maps search for the listing locality, not a verified pin.
- No payment processing, email/SMS notification, CAPTCHA/rate-limiting, agent multi-tenancy or customer accounts.
- Before promoting widely, add anti-spam protection and a privacy notice, test RLS policies, and verify all listing details.
