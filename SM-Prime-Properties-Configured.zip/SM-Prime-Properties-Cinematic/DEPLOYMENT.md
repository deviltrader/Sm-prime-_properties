# Deployment guide — SM Prime Properties

You can deploy the static website from an iPhone, but the first setup needs your own hosting and database accounts. This package does not create accounts or deploy to them automatically.

## Part A — Create the backend

1. Visit https://supabase.com in Safari and create a project.
2. Open **SQL Editor** for the project.
3. Open `supabase-schema.sql` from this package and run all of it.
4. Go to **Authentication → Users** and create an owner account with an email/password you control.
5. Copy that user's UUID.
6. In SQL Editor, run the following after replacing the placeholder:
   `insert into public.property_admins (user_id) values ('YOUR-OWNER-USER-UUID');`
7. In **Project Settings → API** (or API Keys), copy the Project URL and the publishable/anon key.

## Part B — Configure the website

Edit `config.js` in a code editor and set:

```js
window.SM_PRIME_CONFIG = {
  supabaseUrl: "https://YOUR_PROJECT.supabase.co",
  supabaseAnonKey: "YOUR_PUBLIC_PUBLISHABLE_OR_ANON_KEY",
  whatsappNumber: "91XXXXXXXXXX"
};
```

Replace the sample values with your own. WhatsApp must be digits only with country code, without `+` or spaces. The URL and anon/publishable key are intended for browser use **only because the SQL enforces Row Level Security**. Never use the Supabase `service_role` key here.

## Part C — Deploy to Netlify

### Recommended iPhone workflow (GitHub + Netlify)

1. Extract the ZIP in the iPhone Files app.
2. Open https://github.com and create a private repository for the project.
3. Upload the project files and folders from the extracted ZIP. Keep `index.html`, `styles.css`, `app.js`, `config.js`, and `netlify.toml` in the repository root.
4. Open https://app.netlify.com and sign in.
5. Choose **Add new site / Import an existing project**, connect GitHub and select your repository.
6. Build command: leave blank. Publish directory: `.` (the repository root).
7. Deploy. Netlify will show a public URL when deployment succeeds.
8. If you later change `config.js`, commit the change and redeploy.

If Netlify's mobile UI does not allow selecting a folder, use GitHub import rather than the drag-and-drop flow.

## Part D — Add your real properties

1. Open the deployed website URL.
2. Scroll to the footer and select **OWNER LOGIN**.
3. Sign in with the owner account created in Supabase and added to `property_admins`.
4. Add a verified listing: title, type, purpose, locality, asking price, area, status, photo and accurate description.
5. Publish it. It should then appear in the public property catalogue.
6. Submit a test enquiry and confirm it appears in the owner inbox.
7. Test WhatsApp after adding your correct business number to `config.js`.

## Troubleshooting

- **Admin sign-in says backend not connected:** check that both `supabaseUrl` and `supabaseAnonKey` are filled in `config.js`, then redeploy.
- **Sign-in succeeds but listing changes fail:** confirm the exact Auth user's UUID is in `public.property_admins` and the SQL ran without errors.
- **Photos fail:** use JPG, PNG, WebP or AVIF below 8 MB; confirm the Storage policies were created.
- **No property cards appear:** this is expected until you add and publish listings.
- **Enquiries fail:** check the `leads` table and its insert policy in Supabase.
- **WhatsApp does not open:** verify the number is correct, includes country code, and contains digits only.

## Production readiness

The package is a functional starter but is not a full audited production service. Before public advertising, add CAPTCHA/rate limiting to the enquiry endpoint, configure backups, write a privacy notice and terms, test all database policies, and confirm your property listings are authorised and accurate.
