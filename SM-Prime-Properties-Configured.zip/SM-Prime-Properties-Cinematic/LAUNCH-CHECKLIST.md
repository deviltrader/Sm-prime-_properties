# Launch checklist

- [ ] Add Supabase project URL and public key to `config.js`
- [ ] Run `supabase-schema.sql` successfully
- [ ] Create owner user and allowlist its UUID
- [ ] Add the correct WhatsApp business number
- [ ] Deploy to Netlify and test on iPhone
- [ ] Sign in to OWNER LOGIN and test add/edit/delete
- [ ] Test a photo upload
- [ ] Submit a customer enquiry and confirm it is visible to the owner
- [ ] Add a privacy notice and business contact details
- [ ] Replace placeholder hero/section photos if you have licensed local property photography
- [ ] Publish only verified listings with permission to advertise
- [ ] Verify title/ownership, applicable approvals, area, asking price, locality, availability and documents independently
- [ ] Add CAPTCHA/rate limiting before wide public promotion
- [ ] Never collect deposits, identity documents or sensitive financial data through this starter
- [ ] Never put a Supabase service-role key or database password in frontend files
